create function dodajmuzikanta(imee character varying, priimekk character varying, maill character varying, geslo character varying) returns void
    language plpgsql
as
$$
DECLARE BEGIN 
INSERT INTO muzikanti(ime, priimek, maill, email) VALUES (imee,priimekk,maill,geslo); END;
$$;

alter function dodajmuzikanta(varchar, varchar, varchar, varchar) owner to epebibyjgvxunf;

